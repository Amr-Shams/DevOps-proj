I have built the infrastructer of the cloud archtiect that includes: Public and private Subnets + VPC + Route Tables
+ IGW + EIPs in the file Test.yml with parameters in Netowrk-par.json
then used the export and import to assgin the configurations and secuiryt anlgside with ELB in file 
Servers.yml with parameters server-par.json
////// 

aws --profile amr cloudformation create-stack --stack-nam first --template-body file://testing.yml  --parameters file://Netowrk-Par.json --region=us-east-1

+++++

aws --profile amr cloudformation create-stack --stack-nam second --template-body file://Servers.yml  --parameters file://server-par.json --region=us-east-1 

I deleted all the stacks using command 

aws --profile amr cloudformation delete-stack --stack-nam second

aws --profile amr cloudformation delete-stack --stack-nam first